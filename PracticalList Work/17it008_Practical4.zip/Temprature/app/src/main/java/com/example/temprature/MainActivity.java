package com.example.temprature;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {
    Button btn_cf, btn_fc, btn_ck, btn_fk, btn_kf, btn_kc;
    EditText et_f, et_c, et_k;
    RadioButton rb_c, rb_f, rb_k;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_cf = findViewById(R.id.btn_cf);
        btn_ck = findViewById(R.id.btn_ck);

        btn_fc = findViewById(R.id.btn_fc);
        btn_fk = findViewById(R.id.btn_fk);

        btn_kf = findViewById(R.id.btn_kf);
        btn_kc = findViewById(R.id.btn_kc);

        et_f = findViewById(R.id.et_f);
        et_c = findViewById(R.id.et_c);
        et_k=findViewById(R.id.et_k);

        rb_c = findViewById(R.id.rb_c);
        rb_f = findViewById(R.id.rb_f);
        rb_k = findViewById(R.id.rb_k);

        btn_cf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float c = Float.parseFloat(et_c.getText().toString());
                float f = (c*(float) 9/5)+32;
                et_f.setText(""+f);
            }
        });

        btn_ck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float c= Float.parseFloat(et_c.getText().toString());
                float k = c+ (float) 273.15;
                et_k.setText(""+k);
            }
        });

        btn_fc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float f = Float.parseFloat(et_f.getText().toString());
                float c = (f-32)*((float)5/9);
                et_c.setText(""+c);
            }
        });

        btn_fk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float f = Float.parseFloat(et_f.getText().toString());
                float k = (f-32)*((float)5/9)+ (float)273.15;
                et_k.setText(""+k);
            }
        });

        btn_kf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float k = Float.parseFloat(et_k.getText().toString());
                float f = (k-(float)273.15)*((float)9/5)+32;
                et_f.setText(""+f);
            }
        });

        btn_kc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float k = Float.parseFloat(et_k.getText().toString());
                float c = k-(float)273.15;
                et_c.setText(""+c);
            }
        });
    }
}
