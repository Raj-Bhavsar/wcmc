package com.example.wcmc_pract_8_17it022;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {

    private Button b1,b2,b3,b4;
    private FrameLayout myFrame;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b1 = findViewById(R.id.button);
        Button b2 = findViewById(R.id.button2);
        Button b3 = findViewById(R.id.button3);
        Button b4 = findViewById(R.id.button4);

        myFrame = findViewById(R.id.frame1);
        b1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                myFrame.removeAllViews();
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction =fragmentManager.beginTransaction();
                fragment1 frag1 = new fragment1 ();
                fragmentTransaction.add(R.id.frame1,frag1);
                fragmentTransaction.commit();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFrame.removeAllViews();
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragment2 frag2 = new fragment2();
                fragmentTransaction.add(R.id.frame1,frag2);
                fragmentTransaction.commit();
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFrame.removeAllViews();
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragment3 frag3 = new fragment3();
                fragmentTransaction.add(R.id.frame1,frag3);
                fragmentTransaction.commit();
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myFrame.removeAllViews();
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragment4 frag4 = new fragment4();
                fragmentTransaction.add(R.id.frame1,frag4);
                fragmentTransaction.commit();
            }
        });
    }


}
